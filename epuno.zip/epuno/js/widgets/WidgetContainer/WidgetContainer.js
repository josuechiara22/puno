/**
 * Created by emenendez on 15/05/2017.
 */
// Componente
let widgetComponent = {
    template: `
       <div :class="'widget ' + extraclass">
            <div class="titulo-widget">
                <div :class="'icono ' + icon"></div>
                <div class="texto-titulo">{{ titulo }}</div>
                <div class="cerrar esri-icon-close" @click="ocultarWidget"></div>
            </div>
            <div class="body-widget" ref="body">
                <slot></slot>            
            </div>
        </div>
   `,

    // Propiedades que acepta el componente
    props: [
        'titulo', // Titulo del widget

        'icon', // Clase de calcite para el icono a utlizar

        'grupo', // Grupo al que pertenece el widget. Solo un widget de cada grupo puede estar visible al mismo tiempo

        'extraclass' // Class que se adjunta a las clases del nodo principal del widget
    ],

    // Terminada la primera renderización del componente
    mounted: function(){

        // Establecer el grupo por defecto
        this._data._grupo = this.grupo || this._data._grupo;

    },

    // Data del componente
    data: () => {
        return {
            _grupo: '0'
        }
    },

    // Métodos del componente
    methods: {

        // Emitir el evento de cerrado del componente
        ocultarWidget: function(){
            this.$emit('onclose');
        }

    }
};

// Manejador de widgets
let Widgets = new Vue({

    // Elemento del DOM
    el: '#widgets-container',

    // Data de la vista
    data: {

        // Los widgets activos en diferentes grupos
        widgetActivo: {
            0: '',
            1: '',
            2: ''
        }

    },

    // Componentes asociados a esta vista
    components: {
        'widget': widgetComponent
    },

    // Cargar el archivo de estilos
    created: () => {
        if  (!document.head.querySelector('widgetcss')){
            let cssLink = document.createElement('link');
            cssLink.id = "widgetcss";
            cssLink.rel = 'stylesheet';
            cssLink.href = 'js/widgets/WidgetContainer/WidgetContainer.css';
            document.head.appendChild(cssLink);
        }
    },

    // Metodos de la vista
    methods: {

        // Obtiene una referencia al body del widget con el id especificado
        getContainer: function (widgetId) {
            return this.$refs[widgetId].$refs.body;
        },

        // Alternar la visualización del widget.
        toggleWidget: function (widgetId){
            if (!this.$refs[widgetId]){
                return false;
            }

            // Si está activo, ocultarlo. De lo contrario, mostrarlo
            if (this.widgetActivo[this.$refs[widgetId]._data._grupo] === widgetId){
                this.widgetActivo[this.$refs[widgetId]._data._grupo] = '';
            }else{
                this.widgetActivo[this.$refs[widgetId]._data._grupo] = widgetId
            }

            // Avisar del cambio en widget actual
            this.$emit('cambioWidget', {grupo: this.$refs[widgetId]._data._grupo, widgetId: this.widgetActivo[this.$refs[widgetId]._data._grupo]})
        }
    }

});

