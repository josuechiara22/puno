/**
 * Created by emenendez on 21/03/2017.
 */
'use strict';
define([
    // Dojo
    "dojo/_base/declare",
    "dojo/Evented",

    // -- Esri
    // Layers
    "esri/layers/FeatureLayer",
    // Tasks
    "esri/tasks/QueryTask",
    "esri/tasks/support/Query",
    "esri/tasks/support/StatisticDefinition",
    // Symbols
    "esri/Graphic",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/symbols/PictureMarkerSymbol",
    // Renderers
    "esri/renderers/SimpleRenderer",
    "esri/renderers/UniqueValueRenderer",
    "esri/renderers/ClassBreaksRenderer",

    // Vendor

    // Templates
    "dojo/text!./templates/estructuraMapasTematicos.html",
    "dojo/text!./templates/selectorMapasTematicos.html",

    // Config
    "dojo/text!./config/tematicos-suministros.json"
], function(
    // Dojo
    Declare,
    Evented,

    // -- Esri
    // Layers
    FeatureLayer,
    // Tasks
    QueryTask,
    Query,
    StatisticDefinition,
    // Symbols
    Graphic,
    SimpleMarkerSymbol,
    PictureMarkerSymbol,
    // Renderers
    SimpleRenderer,
    UniqueValueRenderer,
    ClassBreaksRenderer,

    // Vendor

    // Templates
    TemplatePrincipal,
    TemplateSelectorTematico,

    // Config
    ConfigTematicoSuministro
    // CSS
){

    //--------------------------------------------------------------------------
    //
    //  Referencias al DOM
    //
    //--------------------------------------------------------------------------
    let _container;
    let _bodyWidget;
    let _contenedorFechas;
    let _selectAnio;
    let _selectMes;
    let _contenedorTablaEstadistica;
    let _btnMenores;
    let _btnMayores;
    let _btnMas;
    //--------------------------------------------------------------------------
    //
    //  Referencias a Objetos
    //
    //--------------------------------------------------------------------------
    let _instancia;
    let _view;
    let _mapa;
    let _urlServicio;
    let _urlWsEstadistica;
    let _urlWsDatos;
    let _AsyncEstadisticas = [];
    let _AsyncConsultaDatos = [];
    let _timeoutRender;
    // Capas de la red
    let _redLayer;
    let _sumLayer;
    let _sedLayer;
    // Variables de Tematicos
    let _sumLayerTituloOriginal;
    let _tematicos; // {idtematico1: {campo: ..., datos: ..., }, idtematico2: {campo: ..., datos: ..., },...}
    let _tematicoActual; // Referencia a uno de los tematicos en el objeto _tematicos
    let _suministrosVisibles;
    let _periodoComercial;
    let _tablaOculta;
    // Referencia a Eventos
    let _mouseMoveListener;

    //--------------------------------------------------------------------------
    //
    //  Constantes
    //
    //--------------------------------------------------------------------------
    const _config = JSON.parse(ConfigTematicoSuministro);
    const _templateSelectorTematico = Handlebars.compile(TemplateSelectorTematico);
    const _sCodSuministroCapa = "SUM_COD_SUM"; // Campo Codigo de suministro en la capa de suministros
    const _codSuministroTabla = "CODIGOSUMINISTRO"; // Campo Codigo de suministro en las tablas estadisticas
    const _idTematicoLibroAcometidas = 'tematico-libro-acometidas';

    //--------------------------------------------------------------------------
    //
    //  Funciones Privadas
    //
    //--------------------------------------------------------------------------
    function _inicializar(){
        // Cargar Estilos
        if  (!document.head.querySelector('mapasTematicos')){
            let cssLink = document.createElement('link');
            cssLink.id = "mapasTematicos";
            cssLink.rel = 'stylesheet';
            cssLink.href = './js/widgets/MapasTematicos/css/mapasTematicos.css';
            document.head.appendChild(cssLink);
        }

        _sumLayerTituloOriginal = _sumLayer.title;

        _container.classList.add('mapas-tematicos-container');
        _container.innerHTML = TemplatePrincipal;

        _capturarReferenciasDOM();

        _configurarPeriodosComerciales();

        _vincularEventos();

        _configurarTematicos();
    }
    //--------------------------------------------------------------------------
    //  Capturar referencias al DOM
    //--------------------------------------------------------------------------

    function _capturarReferenciasDOM(){
        _bodyWidget = _container;
        _contenedorFechas = _bodyWidget.querySelector('.fechas');
        _selectAnio = _bodyWidget.querySelector('#mapas-tematicos-selector-anio');
        _selectMes = _bodyWidget.querySelector('#mapas-tematicos-selector-mes');
        _btnMenores = _bodyWidget.querySelector('.selector-tipo-consumo button[data-tipo-cliente="menor"]');
        _btnMayores = _bodyWidget.querySelector('.selector-tipo-consumo button[data-tipo-cliente="mayor"]');
        _btnMas = _bodyWidget.querySelector('.selector-tipo-consumo button[data-tipo-cliente="mas"]');

        _contenedorTablaEstadistica =  _bodyWidget.querySelector('#estadistica-tematicos');
        _generarSelectoresTematicos();
    }
    //--------------------------------------------------------------------------
    //  Genera los botones de seleccion para los temáticos definidos en la
    //  configuración
    //--------------------------------------------------------------------------

    function _generarSelectoresTematicos(){
        let botoneraMenor = document.createDocumentFragment();
        let botoneraMayor = document.createDocumentFragment();
        let botoneraMas = document.createDocumentFragment();
        let divTemp;

        // Tematicos para clientes mayores y menores
        _config["tematicos"].forEach( (configTematico) => {
            divTemp = document.createElement('div');
            divTemp.innerHTML = _templateSelectorTematico({
                idTematico: configTematico["id"],
                titulo: configTematico["titulo"]
            });
            divTemp.firstElementChild.querySelector('button').addEventListener('click', () => {_generarTematico(configTematico["id"]);} );
            if (configTematico["tipo-cliente"] === "mayor"){
                botoneraMayor.appendChild(divTemp.firstElementChild);
            }else{
                botoneraMenor.appendChild(divTemp.firstElementChild);
            }
        });

        // Tematico de libro de acometidas
        divTemp = document.createElement('div');
        divTemp.innerHTML = _templateSelectorTematico({
            idTematico: _idTematicoLibroAcometidas,
            titulo: 'Libro de Acometidas'
        });
        divTemp.firstElementChild.classList.add('no-estadistica');
        divTemp.firstElementChild.querySelector('button').addEventListener('click', () => {_generarTematicoLibroAcometidas()} );
        botoneraMas.appendChild(divTemp.firstElementChild);

        // Agregar las botoneras al widget
        _bodyWidget.querySelector('.selectores[data-tipo-cliente="menor"]').appendChild(botoneraMenor);
        _bodyWidget.querySelector('.selectores[data-tipo-cliente="mayor"]').appendChild(botoneraMayor);
        _bodyWidget.querySelector('.selectores[data-tipo-cliente="mas"]').appendChild(botoneraMas);
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    function _configurarPeriodosComerciales(){
        // Cargar periodos
        let now = new Date();
        let opciones = document.createDocumentFragment();
        for (let anio = 2015; anio <= now.getFullYear(); anio++){
            let option = document.createElement('option');
            option.value = anio;
            option.textContent = anio;
            opciones.appendChild(option);
        }
        _selectAnio.appendChild(opciones);
        _selectAnio.value = now.getFullYear();

        for (let mes = 1; mes <= 12; mes++){
            let option = document.createElement('option');
            // Dos últimos caracteres de la cadena generada.
            option.value = ("00" + mes).slice(-2);
            option.textContent = ("00" + mes).slice(-2);
            opciones.appendChild(option);
        }
        _selectMes.appendChild(opciones);
        _selectMes.selectedIndex = now.getMonth();

        _periodoComercial = _selectAnio.value + _selectMes.value;
    }

    //--------------------------------------------------------------------------
    //  Vincular eventos
    //--------------------------------------------------------------------------
    function _vincularEventos(){
        _selectAnio.addEventListener('change', _actualizarPeriodo);
        _selectMes.addEventListener('change', _actualizarPeriodo);
        _btnMenores.addEventListener('click', _intercambiarListaTematicos);
        _btnMayores.addEventListener('click', _intercambiarListaTematicos);
        _btnMas.addEventListener('click', _intercambiarListaTematicos);
    }

    //--------------------------------------------------------------------------
    //  Capturar referencias a elementos de la Red
    //--------------------------------------------------------------------------
    function _capturarElementosDeRed(){
        // Obtener referencia a LayerView de Suministros
        _view.whenLayerView(_sumLayer).then(function(lyrView) {
            lyrView.watch("updating", function(actualizado) {
                if (!actualizado) {
                    // Se han obtenido todos los elementos
                    console.timeEnd('carga-suministros');
                    lyrView.queryFeatures().then(function(features) {
                        // Si no se ha definido un temático, no hacer nada.
                        _suministrosVisibles = features;
                        if (_tematicoActual){
                            _cargarDatosTematico();
                        }
                    });
                }else{
                    console.time('carga-suministros');
                }
            });
        });
    }

    //--------------------------------------------------------------------------
    //  Guarda una referencia a la configuración definida para los Tematicos
    //--------------------------------------------------------------------------
    function _configurarTematicos(){
        _urlWsEstadistica = _config['url-servicio'] + '/getEstadistica';
        _urlWsDatos = _config['url-servicio'] + '/getSuministros';
        _tematicos = {};
        // Tematico de Consumo
        _config["tematicos"].forEach( (configTematico) => {
            _tematicos[configTematico["id"]] = {
                id: configTematico["id"],
                idEntidad: configTematico["id-entidad"],
                titulo: configTematico["titulo"],
                campo: configTematico["campo"],
                periodo: configTematico["periodo"],
                defaultColor: configTematico["default-color"],
                defaultLabel: configTematico["default-label"],
                valores: configTematico["valores"],
                rangos: configTematico["rangos"],
                validarExistencia: configTematico["validar-existencia"],
                datos: {}
            }
        });

        // Programar limpieza de datos cada 5 minutos
        setInterval(() => {
            _limpiarDataTematicos();
            _cargarDatosTematico();
        }, 300000);
    }

    //--------------------------------------------------------------------------
    //  Cambia entre la lista de botones
    //--------------------------------------------------------------------------
    function _intercambiarListaTematicos(e){
        let tipo = e.target.getAttribute("data-tipo-cliente");
        let tematicosMenor = _bodyWidget.querySelector('.selectores[data-tipo-cliente="menor"]');
        let tematicosMayor = _bodyWidget.querySelector('.selectores[data-tipo-cliente="mayor"]');
        let tematicosMas = _bodyWidget.querySelector('.selectores[data-tipo-cliente="mas"]');

        _contenedorFechas.style.display = "block"; // Visible por defecto

        _btnMenores.classList.remove('activo');
        tematicosMenor.classList.remove('activo');
        _btnMas.classList.remove('activo');
        tematicosMas.classList.remove('activo');
        _btnMayores.classList.remove('activo');
        tematicosMayor.classList.remove('activo');

        if (tipo === "mayor"){
            _btnMayores.classList.add('activo');
            tematicosMayor.classList.add('activo');
        }else if (tipo === "menor"){
            _btnMenores.classList.add('activo');
            tematicosMenor.classList.add('activo');
        }else{
            _contenedorFechas.style.display = "none"; // Ocultar solo para los tematicos en pestaña "Más"
            _btnMas.classList.add('activo');
            tematicosMas.classList.add('activo');
        }
    }

    //--------------------------------------------------------------------------
    //  Actualiza el periodo comercial que se está mostrando y regenera el
    //  tematico actual
    //--------------------------------------------------------------------------
    function _actualizarPeriodo(){
        _periodoComercial = _selectAnio.value + _selectMes.value;
        if (_tematicoActual){
            _limpiarDataTematicos();
            _generarTematico(_tematicoActual.id);
        }
    }

    //--------------------------------------------------------------------------
    //  Elimina los datos guardados en memoria durante el uso de los mapas
    //  tematicos
    //--------------------------------------------------------------------------
    function _limpiarDataTematicos() {
        Object.keys(_tematicos).forEach((idTematico) => {
            _tematicos[idTematico].datos = {};
        });

        console.log('Limpieza de Tematicos realizada.');
    }

    //--------------------------------------------------------------------------
    //  Genera el render necesario y actualiza la interfaz para el temático
    //  seleccionado en la variable _tematicoActual
    //--------------------------------------------------------------------------
    function _generarTematico(idTematico){
        try{
            _resaltarSuministrosLibro(false);
            _tematicoActual = _tematicos[idTematico];

            // Crear Render
            let defaultSymbol = _tematicoActual.defaultColor === false ? null : _sumSymbol(_tematicoActual.defaultColor || 'gray');
            let defaultLabel = _tematicoActual.defaultLabel || 'Otros';
            let renderer;
            switch (true){
                case Boolean(_tematicoActual.valores):
                    let uniqueInfos = _tematicoActual.valores.map( (info) => {
                        return {
                            value: info.valor,
                            label: info.label,
                            symbol: _sumSymbol(info.color, info.size)
                        };
                    });

                    renderer = new UniqueValueRenderer({
                        field: _renderTematicos,
                        uniqueValueInfos: uniqueInfos
                    });
                    break;
                case Boolean(_tematicoActual.rangos):
                    let maxAnterior;
                    let classBreakInfos = _tematicoActual.rangos.map( (info) => {
                        let minValue = maxAnterior || 0;
                        maxAnterior = info['valor-max'];
                        return {
                            minValue: minValue,
                            maxValue: info['valor-max'],
                            label: info.label,
                            symbol: _sumSymbol(info.color, info.size)
                        };
                    });

                    renderer = new ClassBreaksRenderer({
                        field: _renderTematicos,
                        classBreakInfos: classBreakInfos
                    });
                    break;
            }
            renderer.defaultSymbol = defaultSymbol;
            renderer.defaultLabel=  defaultLabel;
            renderer.legendOptions = {
                title: `${_tematicoActual.titulo} (${_periodoComercial})`
            };
            _sumLayer.renderer = renderer;
            // _sumLayer.title = `${_sumLayerTituloOriginal } - ${_tematicoActual.titulo}`;
            _cargarDatosTematico();

            _generarEstadisticasTematicoActual();
        }catch (e){
            console.error('Error durante generación de temático.', e);
            return false;
        }
    }

    function _generarTematicoLibroAcometidas(){
        // Cancelar acciones relacionadas a tematicos
        _ocultarTablaEstadistica(); // Ocultar el tematico actual si existe
        // Mostar boton de tematico de acometidas
        let boton = _bodyWidget.querySelector(`.boton-tematico[data-id-tematico='${_idTematicoLibroAcometidas}']`);
        boton.classList.add("activo");

        // Aplicar render necesario
        let rendererLibros = new UniqueValueRenderer({
            field: _renderLibroAcometidas,
            defaultSymbol: new SimpleMarkerSymbol({
                size: '10px',
                outline: {
                    color: "gray",
                    width: 2
                }
            }),
        });

        rendererLibros.addUniqueValueInfo('Sin Información', new SimpleMarkerSymbol({color: 'gray',size: '10px'}));

        _sumLayer.renderer = rendererLibros;
        if (_mouseMoveListener && typeof (_mouseMoveListener.remove) === "function"){
            _mouseMoveListener.remove();
        }
        _resaltarSuministrosLibro();

    }

    function _generarEstadisticasTematicoActual(){
        // Cancelar la obtencion estadístca
        _cancelarAsyncEstadisticas();

        // Cerrar el ceontedor estadistico que se encuentre abierto
        _tablaOculta = _ocultarTablaEstadistica();

        // Mostrar señal de cargando en el tematico actual
        let boton = _bodyWidget.querySelector(`.boton-tematico[data-id-tematico='${_tematicoActual.id}']`);
        boton.classList.add('procesando');

        // Obtener información estadística
        let terminado = null;
        if (_tematicoActual.rangos){
            terminado = _obtenerInfoEstadisticaRangos();
        }else if(_tematicoActual.validarExistencia){
            terminado = _obtenerInfoEstadisticaValidaExistencia();
        }else{
            terminado = _obtenerInfoEstadisticaValoresUnicos();
        }
        // Mostrar tabla estadistica cuando esta haya sido creada y la(s) anterio(res) haya(n) sido cerrada(s)
        Promise.all([_tablaOculta, terminado]).then(() => { _mostrarTablaEstadistica() });
    }

    //--------------------------------------------------------------------------
    //  Obtiene los datos requeridos para graficar los tematicos desde las
    //  tablas de los servicios. Los datos son obtenidos solo para las entidades
    //  actualmente visibles en el mapa.
    //--------------------------------------------------------------------------
    function _cargarDatosTematico(){
        if (!_suministrosVisibles || !_tematicoActual){
            return false;
        }

        _cancelarAsyncConsultaDatos();

        // Generar códigos para el query
        let codigosBusqueda = [];
        _suministrosVisibles.forEach(function(result) {
            if (!_tematicoActual.datos.hasOwnProperty(result.attributes[_sCodSuministroCapa])){
                codigosBusqueda.push(`${result.attributes[_sCodSuministroCapa]}`);
            }
        });

        // Si no hay códigos para cargar, entonces salir
        if (codigosBusqueda.length < 1){
            return false;
        }

        // Crear Filtro para la búsqueda
        let filtroTabla = `${_codSuministroTabla} IN (${codigosBusqueda.join(',')})`;
        //filtroTabla += ` AND ${_obtenerFiltroPeriodo()}`;

        console.time('carga-datos');
        // Indicar a la vista que se está realizando una carga de información
        _view.updating = true;

        let consultaCantidad = fetchJSON(_urlWsEstadistica, {
            periodo: _periodoComercial,
            condicion: filtroTabla,
            entidad: _tematicoActual.idEntidad
        }).then( data => {
            let maxRecordCount = 1000;
            let promises = [];
            for (let i = 0; i < data.count; i += maxRecordCount){
                let query = fetchJSON(_urlWsDatos, {
                    periodo: _periodoComercial,
                    condicion: filtroTabla,
                    entidad: _tematicoActual.idEntidad,
                    offset: i,
                    limit: maxRecordCount,
                    campos: `SUM_ID, ${_codSuministroTabla}, ${_tematicoActual.campo}`
                });
                promises.push(query);
            }

            // Guardar referencia a las tareas asíncronas de obtención de datos
            _AsyncConsultaDatos = _AsyncConsultaDatos.concat(promises);

            Promise.all(promises).then( resultados => {
                let registros = [];
                // Si se encontró información resultante
                if (resultados && resultados.length > 0){
                    // Obtener un unico array con todos los registros encontrados en las consultas
                    registros = resultados.reduce( (ant, act) => ant.concat(act.items), []);
                    // Crear un espacio de datos para cada codigo buscado
                    codigosBusqueda.forEach( codigo => _tematicoActual.datos[codigo] = null );
                    // Guardar los datos encontrados para cada suministros
                    registros.forEach( registro => {
                        _tematicoActual.datos[registro[_codSuministroTabla]] = registro[_tematicoActual.campo];
                    });
                }
                console.timeEnd('carga-datos');
                console.log(`Busqueda realizada: <br> Buscados: ${codigosBusqueda.length} <br> Encontrados: ${registros.length}`);

                // Indicar a la vista que se concluyó con la carga de información
                _view.updating = false;

                // Forzar redibujado
                _sumLayer.renderer = _sumLayer.renderer.clone();

            });
        });

        _AsyncConsultaDatos.push(consultaCantidad);
    }

    //--------------------------------------------------------------------------
    //  Permite realizar el renderizado de los suministros a partir de los datos
    //  presentes en las tablas obtenidas desde los servicios.
    //--------------------------------------------------------------------------
    function _renderTematicos(graphic){
        if (_tematicoActual){
            try{
                if (graphic.attributes[_sCodSuministroCapa] &&
                    typeof _tematicoActual.datos[graphic.attributes[_sCodSuministroCapa].trim()] !== 'undefined' &&
                    _tematicoActual.datos[graphic.attributes[_sCodSuministroCapa].trim()] !== null){
                    if (_tematicoActual.validarExistencia){
                        // Si el temático solo necesita que se valide la existencia del elemento en los datos.
                        return 1;
                    }else{
                        return _tematicoActual.datos[graphic.attributes[_sCodSuministroCapa].trim()];
                    }
                }
            }
            catch(err){
                console.log(err);
            }
            return -1;
        }
    }

    //--------------------------------------------------------------------------
    //  Render de tematico de Libro de Acometidas
    //--------------------------------------------------------------------------
    function _renderLibroAcometidas(graphic){
        let libro = graphic.attributes['SUM_COD_RUT'] ? graphic.attributes['SUM_COD_RUT'].slice(0,7) : 'Sin Información';
        let renderer = _sumLayer.renderer;
        if (!renderer.uniqueValueInfos.find( x => x.value === libro)){
            // Crear value
            let color = randomColor(libro);
            renderer.addUniqueValueInfo(libro, new SimpleMarkerSymbol({
                color: color,
                size: '10px',
                outline: {
                    color: increase_brightness(color, 20),
                    width: 1
                }
            }));
            _emitirActualizacionRender();
        }
        return libro;
    }

    function _emitirActualizacionRender(){
        if (!_timeoutRender){
            setTimeout( () => {
                _timeoutRender = null;
                _instancia.emit('render-update', {});
            }, 500);
        }
    }

    function _resaltarSuministrosLibro(continuar){
        if (continuar === false){
            console.log('Solicitud de stop');
            if (_mouseMoveListener && typeof(_mouseMoveListener.remove) === "function"){
                _mouseMoveListener.remove();
            }
            _mouseMoveListener = null;
            return;
        }

        let higthLigthSym = new SimpleMarkerSymbol({
            size: '12px',
            outline: {
                color: [0, 255, 123, 0.5],
                width: 2
            }
        });

        _mouseMoveListener = _view.on("pointer-move", function(event) {
            _view.hitTest(event).then(resultado => {
                let punto = resultado.results[0];
                if (punto){
                    // Verificar que existan resultados y que sean de la capa de suministros.
                    if (punto.graphic.layer === _sumLayer ) {
                        let libro = punto.graphic.attributes['SUM_COD_RUT'].slice(0,7);

                        // Obtener todos los suministros visibles
                        _view.layerViews.find( lv => lv.layer === _sumLayer ).queryFeatures().then( features => {
                            let sumLibro = features.filter( f => (f.attributes['SUM_COD_RUT'] || '').slice(0,7) === libro);

                            sumLibro.forEach( s => {
                                _view.graphics.add(new Graphic({
                                    geometry: s.geometry,
                                    symbol: higthLigthSym,
                                    attributes: {}
                                }))
                            });
                        });
                    }
                }else{
                    _view.graphics.removeAll();
                }
            });
        });
    }

    function _obtenerFiltroPeriodo(){
        let filtro = "";
        if (!_periodoComercial){
            _actualizarPeriodo();
        }
        switch (_tematicoActual.periodo){
            case 'semestral':
                let anio = _periodoComercial.substring(0, 4);
                let mes =  _periodoComercial.substring(4, 6);
                let semestre = Number(mes) <= 6 ? `${anio}_1` : `${anio}_2`;
                filtro = ` NombrePeriodoNTCSE like '%${semestre}'` ;
                break;
            default:
                filtro = ` CodigoPeriodoComercial = ${_periodoComercial}`;
        }
        return filtro
    }

    function _obtenerFiltroEstadistica(){
        if (!_sumLayer.definitionExpression){
            return "1=1"
        }
        if (_sumLayer.definitionExpression.indexOf('SUM_COD_SED') > -1){
            return _sumLayer.definitionExpression
                .replace(/SUM_COD_SED/g, 'SED_COD_SED') // Cambiar campo
        }else{
            return _sumLayer.definitionExpression
                .replace(/SUM_COD_SUM/g, 'CODIGOSUMINISTRO') // Cambiar campo
                .replace(new RegExp("'", 'g'), ""); // Quitar comillas simples
        }

    }

    //--------------------------------------------------------------------------
    //  Obtiene informacón estaadistica segun el tematico actual
    //--------------------------------------------------------------------------
    function _obtenerInfoEstadisticaValoresUnicos(){
        if (!_tematicoActual){
            return false;
        }
        let resolve, reject;
        let resultado = new Promise( (res, rej) => {
            resolve = res;
            reject = rej;
        });
        _inicializarTablaEstadistica();

        let filtroSuministros = _obtenerFiltroEstadistica();

        // Verificar si se está filtrando por suministro
        let arrayWhere = [];
        if (filtroSuministros.indexOf("CODIGOSUMINISTRO") >= 0){
            let arraySuministros = filtroSuministros.match(/\d+/g);

            for (let i = 0; 500 * i <= arraySuministros.length; i++){
                let concatenado = arraySuministros
                    .slice(i * 500, (i+1)*500)
                    .reduce( (anterior, suministro) => `${anterior}, ${suministro}`, '00');
                arrayWhere.push(`1=1 AND (CODIGOSUMINISTRO IN (${concatenado}))`);
            }

        }else{
            arrayWhere.push(`1=1 AND (${filtroSuministros})`)
        }

        let arrayConsultas = [];

        // realizar una consulta por cada filtro
        arrayWhere.forEach( where => {
            arrayConsultas.push(
                fetchJSON(_urlWsEstadistica, {
                    periodo: _periodoComercial,
                    condicion: where,
                    entidad: _tematicoActual.idEntidad,
                    agrupar: _tematicoActual.campo
                })
            );
        });

        Promise.all(arrayConsultas).then(function(arrayResultado){
            // Juntar todos los resultados en un solo array
            let resultado = arrayResultado.reduce( (concatenado,resultadoConsulta) => concatenado.concat(resultadoConsulta.items), [] );

            let valores = {};
            resultado.forEach( item => {
                if (!valores[item[_tematicoActual.campo]]){
                    valores[item[_tematicoActual.campo]] = item['CANTIDAD'];
                }else{
                    valores[item[_tematicoActual.campo]] += item['CANTIDAD'];
                }
            });

            // Si no se ha especificado la lista de valores unicos
            if (!_tematicoActual.valores || _tematicoActual.valores.length === 0){
                // Cargar todos los valores unicos encontrados para el campo del tematico
                Object.keys(valores).forEach(key => {
                    _agregarFilaEstadistica(key, valores[key]);
                });
            }else{
                _tematicoActual.valores.forEach( valorUnico => {
                    let fila = _agregarFilaEstadistica(valorUnico.label || valorUnico.valor, '<i class="icono-carga esri-icon-refresh"></i>', valorUnico.color);
                    // let feature = resultado.features.find( f => f.attributes[_tematicoActual.campo].toString() === valorUnico.valor.toString());
                    let valor = valores[valorUnico.valor.toString()];
                    if (valor){
                        fila.celdaValor.textContent = valor;
                    }else{
                        fila.celdaValor.textContent = "0";
                    }
                });
            }

            // Resoler el promise de resultado.
            resolve(true);
        });

        arrayConsultas.forEach( consulta => _AsyncEstadisticas.push(consulta));

        return resultado;
    }

    //--------------------------------------------------------------------------
    //  Obtiene informacón estaadistica segun el tematico actual en rangos de
    //  valores
    //--------------------------------------------------------------------------
    function _obtenerInfoEstadisticaRangos(){
        if (!_tematicoActual){
            return false;
        }
        _inicializarTablaEstadistica();
        let valAnterior = -1;

        console.log('Cargando estadisticas rangos');
        _tematicoActual.rangos.forEach( rango => {
            let fila = _agregarFilaEstadistica(rango.label || rango['valor-max'], '<i class="icono-carga esri-icon-refresh"></i>', rango.color);
            let where =
                `${_tematicoActual.campo} > ${valAnterior} AND ` +
                `${_tematicoActual.campo} <= ${rango['valor-max']} AND ` +
                `(${_obtenerFiltroEstadistica()})`;

            let consulta = fetchJSON(_urlWsEstadistica, {
                periodo: _periodoComercial,
                condicion: where,
                entidad: _tematicoActual.idEntidad
            }).then( data => {
                fila.celdaValor.textContent = data.count;
            });
            valAnterior = rango['valor-max'];
            _AsyncEstadisticas.push(consulta);
        });

        Promise.all(_AsyncEstadisticas).then( _ => {
            console.log('Carga de rangos completada');
        });

        return Promise.resolve();

    }
    //--------------------------------------------------------------------------
    //  Obtiene informacón la cantidad de registros existentes
    //--------------------------------------------------------------------------
    function _obtenerInfoEstadisticaValidaExistencia(){
        if (!_tematicoActual){
            return false;
        }
        _inicializarTablaEstadistica();

        let where = `1=1 AND (${_obtenerFiltroEstadistica()}) `;
        let fila = _agregarFilaEstadistica(_tematicoActual.valores[0].label || _tematicoActual.valores[0].valor, '<i class="icono-carga esri-icon-refresh"></i>', _tematicoActual.valores[0].color);
        let consulta = fetchJSON(_urlWsEstadistica,{
            periodo: _periodoComercial,
            condicion: where,
            entidad: _tematicoActual.idEntidad
        }).then( data => {
            fila.celdaValor.textContent = data.count;
        });

        _AsyncEstadisticas.push(consulta);

        return consulta;
    }
    function _cancelarAsyncEstadisticas(){
        if (Array.isArray(_AsyncEstadisticas)){
            _AsyncEstadisticas.forEach( tarea => {
               if (typeof(tarea.cancel) === "function"){
                   tarea.cancel();
               }
            });
        }
        _AsyncEstadisticas = [];
    }

    function _cancelarAsyncConsultaDatos(){
        if (Array.isArray(_AsyncConsultaDatos)){
            _AsyncConsultaDatos.forEach( tarea => {
                if (typeof(tarea.cancel) === "function"){
                    tarea.cancel();
                }
            });
        }
        _AsyncConsultaDatos = [];
    }

    function _inicializarTablaEstadistica(){
        let tablaEstadistica = _bodyWidget.querySelector(`.boton-tematico[data-id-tematico='${_tematicoActual.id}'] table`);
        tablaEstadistica.tBodies[0].innerHTML = "";

    }
    function _mostrarTablaEstadistica(){
        let boton = _bodyWidget.querySelector(`.boton-tematico[data-id-tematico='${_tematicoActual.id}']`);
        boton.classList.remove("procesando");
        boton.classList.add("activo");
    }

    function _ocultarTablaEstadistica(){
        let botonesActivos = _bodyWidget.querySelectorAll(`.boton-tematico.activo, .boton-tematico.procesando`);
        // Retirar la clase abierto de todos los contenedores que la tengan
        botonesActivos.forEach( cont => {
            cont.classList.remove("activo");
            cont.classList.remove("procesando");
        } );

        return new Promise((resolve) => {
            // Resolver la promesa cuando la animación termine 0.5s
            setTimeout( () => resolve(), 500);
        });
    }
    function _agregarFilaEstadistica(etiqueta, valor, color){
        let tablaEstadistica = _bodyWidget.querySelector(`.boton-tematico[data-id-tematico='${_tematicoActual.id}'] table`);
        let fila = tablaEstadistica.tBodies[0].insertRow();
        let celdaSimbolo = fila.insertCell(0);
        let celdaEtiqueta = fila.insertCell(1);
        let celdaValor = fila.insertCell(2);
        let simbolo = document.createElement('span');

        simbolo.className = "simbolo-suministro-estadistica";
        simbolo.style.backgroundColor = color;

        celdaSimbolo.appendChild(simbolo);
        celdaEtiqueta.textContent = etiqueta;
        celdaValor.innerHTML = valor;

        return {
            celdaSimbolo: celdaSimbolo,
            celdaEtiqueta: celdaEtiqueta,
            celdaValor: celdaValor
        };
    }
    //--------------------------------------------------------------------------
    //  Permite crear un nuevo PointSymbol para los suministros
    //--------------------------------------------------------------------------
    function _sumSymbol(color, size){
        return new SimpleMarkerSymbol({
            size: size || 6,
            color: color || "red",
            outline: {
                color: [128,128,128],
                width: 0.5
            }
        });
    }

    return Declare([Evented], {

        //----------------------------------
        //  Constructor
        //----------------------------------
        constructor: function(container, config){
            _container = container;
            _instancia = this;

            // Obtener referencia a mapa
            _view = config.view;
            _mapa = config.view.map;
            _sumLayer = config.layerSuministros;
            _redLayer = config.layerRed;
            _redLayer.then( () => {
                _sedLayer = _redLayer.allSublayers.find( layer => layer.id === config.layerSedId );
                _sedLayer.definitionExpression = _sedLayer.definitionExpression || "1=1"
            });
            _urlServicio = config.urlServicio;
            _capturarElementosDeRed();
            _inicializar();
        },
        reload: function (){
            let btnActual = _bodyWidget.querySelector('.selectores .boton-tematico.activo button');
            if (btnActual){
                btnActual.click();
            }
        }
    });
});