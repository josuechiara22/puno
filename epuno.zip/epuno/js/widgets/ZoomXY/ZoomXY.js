/**
 * Created by emenendez on 14/02/2017.
 */
'use strict';
define([
    // Dojo
    "dojo/_base/declare",
	"dojo/dom-construct",
    "dojo/Evented",

    // -- Esri
    // Tasks
    "esri/tasks/QueryTask",
    "esri/tasks/support/Query",
	"esri/tasks/GeometryService",
	"esri/tasks/support/ProjectParameters",
    "esri/geometry/SpatialReference",
	"esri/geometry/Point",
    // Symbols
    "esri/Graphic",
    "esri/symbols/PictureMarkerSymbol",

    // Vendor

    // Templates
    "dojo/text!./templates/Widget.html"
    // Config
    //"dojo/text!./css/filtroAvanzado.css"
], function(
    // Dojo
    Declare,
	domConstruct,
    Evented,

    // -- Esri
    // Tasks
    QueryTask,
    Query,
	GeometryService,
	ProjectParameters,
	SpatialReference,
	Point,
    //Symbols
    Graphic,
    PictureMarkerSymbol,

    // Vendor

    // Templates
    TemplatePrincipal
    // Config
    // CSS
){

    //--------------------------------------------------------------------------
    //
    //  Referencias al DOM
    //
    //--------------------------------------------------------------------------
	let _selectSist;
	let _selectZona;
	let _btnLocalizar;
	var eventos = [];
	
	let _coordenadaX;
	let _coordenadaY;
	let _label_X;
	let _label_Y;
	let _label_T;
	
    let _container;
    // Controles de filtro por Zona
    let _txtCodZona;
    let _mensajeErrorZona;
    let _btnFiltrarZona;
    let _btnLimpiarZona;
    // Controles de filtro por SET
    let _btnFiltrarSet;
    let _mensajeErrorSet;
    let _txtCodSet;
    let _btnLimpiarSet;
    // Controles de filtro por alimentador
    let _txtCodAlimentador;
    let _mensajeErrorAlimentador;
    let _btnFiltrarAlimentador;
    let _btnLimpiarAlimentador;
    // Controles de filtro por Subestacion
    let _txtCodSed;
    let _mensajeErrorSed;
    let _btnFiltrarSed;
    let _btnLimpiarSed;
    // Controles de filtro por Suministro
    let _txtCodSum;
    let _mensajeErrorSum;
    let _btnFiltrarSum;
    let _btnLimpiarSum;
    //--------------------------------------------------------------------------
    //
    //  Referencias a Objetos
    //
    //--------------------------------------------------------------------------
    let _instancia;
    let _view;
    let _mapa;
    let _configRed;
    let _filtroActual;

    // Cartografía
    let _zonaLayer;
    // Red de Alta Tensión
    let _setLayer;
    let _tatLayer;
    let _transformadorPotenciaAt;
    let _centroGeneracionAt;
    let _equipoProteccionAt;
    let _estructuraAt;
    let _barraElectricaAt;
    let _pararrayoAt;
    let _puestaTierraAt;
    let _retenidaAt;
    let _grupoGeneracionAt;
    let _casaMaquinaAt;
    let _bocatomaAt;
    let _interruptorAt;
    let _canalesAt;
    let _camaraAt;
    let _tunelesAt;
    let _desarenadorAt;
    let _tuberiaPresionAt;
    // Red de Media Tensión
    let _layerRed;
    let _alimentadorMT;
    let _transformadorMT;
    let _transformadorMixtoMT;
    let _tmtLayer;
    let _puestaTierraMT;
    let _pararrayoMT;
    let _retenidaMT;
    let _recloserMT;
    let _estructuraMT;
    let _reguladorMt;
    let _interruptorMt;
    let _seccionalizadorMt;
    let _seccionadorMt;
    // Red de Baja Tension
    let _sedLayer;
    let _circuitoLayer;
    let _tbtLayer;
    let _tapLayer;
    let _acomLayer;
    let _sumLayer;
    let _sumFeatureLayer;
    let _equipoControlAp;
    let _estructuraBt;
    let _retenidaBt;
    let _puestaTierraBt;
    let _equipoApBt;

    // Agrupadores de red
    let _redAT;
    let _redMT;
    let _redBT;
    //let _templatePrincipal = Handlebars.compile(TemplatePrincipal);

    //--------------------------------------------------------------------------
    //
    //  Constantes
    //
    //--------------------------------------------------------------------------
    const _mostrar = true;
    const _ocultar = false;
    //--------------------------------------------------------------------------
    //
    //  Funciones Privadas
    //
    //--------------------------------------------------------------------------
    function _inicializar(){
		
        // Cargar Estilos
        if  (!document.head.querySelector('filtroAvanzado')){
            let cssLink = document.createElement('link');
            cssLink.id = "filtroAvanzado";
            cssLink.rel = 'stylesheet';
            cssLink.href = './js/widgets/FiltroAvanzado/css/filtroAvanzado.css';
            document.head.appendChild(cssLink);
        }

        // Contenedor de Filtros
        //_filtroActual = {};

        //_container.classList.add('filtro-avanzado-container');
        _container.innerHTML = TemplatePrincipal;

        _capturarElementosDeRed();
        _capturarReferenciasDOM();
        _vincularEventos();

    }
    //--------------------------------------------------------------------------
    //  Capturar referencias al DOM
    //--------------------------------------------------------------------------
    function _capturarReferenciasDOM(){
		//--Datos Localización por Coordenadas
        _selectSist   = _container.querySelector('#coordenada-selector-codigo-sistema');
        _selectZona   = _container.querySelector('#coordenada-selector-codigo-zona');
        _btnLocalizar = _container.querySelector('#coordenada-btn-localizar-coord');
		
		
        _txtCodZona = _container.querySelector('#filtro-avanzado-txt-codigo-zona');
        _mensajeErrorZona = _container.querySelector('#filtro-avanzado-txt-codigo-zona + .filtro-avanzado-error');
        _btnFiltrarZona = _container.querySelector('#filtro-avanzado-btn-filtrar-zona');
        _btnLimpiarZona = _container.querySelector('#filtro-avanzado-btn-limpiar-zona');

        _txtCodSet = _container.querySelector('#filtro-avanzado-txt-codigo-set');
        _mensajeErrorSet = _container.querySelector('#filtro-avanzado-txt-codigo-set + .filtro-avanzado-error');
        _btnFiltrarSet = _container.querySelector('#filtro-avanzado-btn-filtrar-set');
        _btnLimpiarSet = _container.querySelector('#filtro-avanzado-btn-limpiar-set');

        _txtCodAlimentador = _container.querySelector('#filtro-avanzado-txt-codigo-alimentador');
        _mensajeErrorAlimentador = _container.querySelector('#filtro-avanzado-txt-codigo-alimentador + .filtro-avanzado-error');
        _btnFiltrarAlimentador = _container.querySelector('#filtro-avanzado-btn-filtrar-alimentador');
        _btnLimpiarAlimentador = _container.querySelector('#filtro-avanzado-btn-limpiar-alimentador');

        _txtCodSed = _container.querySelector('#filtro-avanzado-txt-codigo-sed');
        _mensajeErrorSed = _container.querySelector('#filtro-avanzado-txt-codigo-sed + .filtro-avanzado-error');
        _btnFiltrarSed = _container.querySelector('#filtro-avanzado-btn-filtrar-sed');
        _btnLimpiarSed = _container.querySelector('#filtro-avanzado-btn-limpiar-sed');

        _txtCodSum = _container.querySelector('#filtro-avanzado-txt-codigo-suministro');
        _mensajeErrorSum = _container.querySelector('#filtro-avanzado-txt-codigo-suministro + .filtro-avanzado-error');
        _btnFiltrarSum = _container.querySelector('#filtro-avanzado-btn-filtrar-suministro');
        _btnLimpiarSum = _container.querySelector('#filtro-avanzado-btn-limpiar-suministro');
    }
    //--------------------------------------------------------------------------
    //  Vincular eventos
    //--------------------------------------------------------------------------
    function _vincularEventos(){
        // Eventos de botones
	    _selectSist.addEventListener('change', function(){_getSistemaCoordenadoZona();});
        _btnLocalizar.addEventListener('click', function(){_setZoomToXY();})
			
        /*eventos.push(function(){
            _selectSist.addEventListener('change', function(){_getSistemaCoordenadoZona();});
            _btnLocalizar.addEventListener('click', function(){_setZoomToXY();})
            this.remove = function(){
                _selectSist.removeEventListener('change', function(){_getSistemaCoordenadoZona();});
                _btnLocalizar.removeEventListener('click', function(){_setZoomToXY();})
            };
            return this;
        }());
		*/

        _btnFiltrarSet.addEventListener('click', () => { _filtrarRedSet(_txtCodSet.value) } );
        _btnLimpiarSet.addEventListener('click', () => { _filtrarRedSet(); _txtCodSet.value = ''; } );

        _btnFiltrarAlimentador.addEventListener('click', () => { _filtrarRedAlimentador(_txtCodAlimentador.value) } );
        _btnLimpiarAlimentador.addEventListener('click', () => { _filtrarRedAlimentador(); _txtCodAlimentador.value = ''; } );

        _btnFiltrarSed.addEventListener('click', () => { _alternarVisibilidadRed(_redMT, _ocultar); _filtrarRedSed(_txtCodSed.value).then( () => _acercarALayer(_tbtLayer));  } );
        _btnLimpiarSed.addEventListener('click', () => { _alternarVisibilidadRed(_redMT, _mostrar); _filtrarRedSed(); _txtCodSed.value = ''; } );

        _btnFiltrarSum.addEventListener('click', () => {_mostrarRelacionSuministroSED(_txtCodSum.value); } );
        _btnLimpiarSum.addEventListener('click', () => {_limpiarMarcadores(); _txtCodSum.value = ''; } );

        _btnFiltrarZona.addEventListener('click', () => { _filtrarRedZona(_txtCodZona.value);} );
        _btnLimpiarZona.addEventListener('click', () => { _filtrarRedZona(); _txtCodZona.value = ''; } );

    }
	
    function _getSistemaCoordenadoZona() {
        _label_X   = _container.querySelector('#coordenada-label-coord-x');
        _label_Y   = _container.querySelector('#coordenada-label-coord-y');
        _label_T   = _container.querySelector('#coordenada-label-tipo');
        _coordenadaX = _container.querySelector('#coordenada-input-coord-x');
        _coordenadaY = _container.querySelector('#coordenada-input-coord-y');

        var data =  [ {"sistema":1, "id":4326, "valor": "Grados Decimales"},
                      {"sistema":2, "id":32717, "valor": "WGS84 Zona 17S"},
                      {"sistema":2, "id":32718, "valor": "WGS84 Zona 18S"},
                      {"sistema":2, "id":32719, "valor": "WGS84 Zona 19S"}];

        //--
        _label_X.innerText  = 'Coordenada X';
        _label_Y.innerText  = 'Coordenada Y';
        _label_T.innerText  = 'Tipo';
        _coordenadaX.placeholder = '-77.099548'
        _coordenadaY.placeholder = '-12.039645'           

        if (_selectSist.value ==2){
            _label_T.innerText  = 'Zona';
            _label_X.innerText  = 'Este';
            _label_Y.innerText  = 'Norte';
            _coordenadaX.placeholder = '2719101'
            _coordenadaY.placeholder = '8666796'
        }

        //--remover options existentes
        _selectZona.options.length = 0;
        data.forEach( function( item ) {
            if (item.sistema==_selectSist.value){
                var option = domConstruct.create("option");
                option.text = item.valor;
                option.value = item.id;
                _selectZona.add(option);
            }
        });
    }

    function _setZoomToXY() {
        //--Obtenemos las Coordenadas XY
         let _coordenadaX = _container.querySelector('#coordenada-input-coord-x');
         let _coordenadaY = _container.querySelector('#coordenada-input-coord-y');
         var oGeometryService = new GeometryService( "https://utility.arcgisonline.com/ArcGIS/rest/services/Geometry/GeometryServer" );
         var inSR = new SpatialReference({ wkid: _selectZona.value });
         var outSR = new SpatialReference({ wkid: _view.spatialReference.wkid});
         var _point = new  Point(_coordenadaX.value, _coordenadaY.value,inSR);
 
         var params = new ProjectParameters();
         params.geometries = [_point];
         params.outSpatialReference = outSR;
         //params.transformation = inSR;
         oGeometryService.project(params).then(function(projectedPoint){
             // The promise resolves to the value stored in projectedGeoms
             var point = new Point(projectedPoint[0].x, projectedPoint[0].y, outSR);
             var symbol = new PictureMarkerSymbol({
                 url: "js/widgets/ZoomXY/img/chinche_azul.png",
                 width: 20,
                 height: 30
             });
			
			_limpiarMarcadores();
			
             var graphic = new Graphic(point, symbol);
			_view.graphics.add( new Graphic({
                geometry: graphic.geometry,
                symbol: symbol,
                attributes: []
            }));
			_view.goTo({target: graphic, zoom: 19});
			
             //lyrPuntos.clear();
             //lyrPuntos.add(graphic);
             //zoom to the selected feature
            // map.centerAndZoom(point, 12);
         }, function(error){
             // Print error if promise is rejected
             console.error(error);
         });

    }
    //--------------------------------------------------------------------------
    //  Emite el evento change para notificar a quienes escucha que algún filtro
    //  ha cambiado.
    //--------------------------------------------------------------------------
    function _emitChange(e){
        console.log(e);
        _instancia.emit("change", {});
    }

    //--------------------------------------------------------------------------
    //  Capturar referencias a elementos de la Red
    //--------------------------------------------------------------------------
    function _capturarElementosDeRed(){
        _layerRed.then( () => {
            // Cartografia
            _zonaLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['zonaFacturacionLayerId']);

            // Red de Alta Tensión
            _setLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['setLayerId']);
            _tatLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['tatLayerId']);
            _transformadorPotenciaAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['transformadorPotenciaAtLayerId']);
            _centroGeneracionAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['centroGeneracionAtLayerId']);
            _equipoProteccionAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['equipoProteccionAtLayerId']);
            _estructuraAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['estructuraAtLayerId']);
            _barraElectricaAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['barraElectricaAtLayerId']);
            _pararrayoAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['pararrayoAtLayerId']);
            _puestaTierraAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['puestaTierraAtLayerId']);
            _retenidaAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['retenidaAtLayerId']);
            _grupoGeneracionAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['grupoGeneracionAtLayerId']);
            _casaMaquinaAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['casaMaquinaAtLayerId']);
            _bocatomaAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['bocatomaAtLayerId']);
            _interruptorAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['interruptorAtLayerId']);
            _canalesAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['canalesAtLayerId']);
            _camaraAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['camaraAtLayerId']);
            _tunelesAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['tunelesAtLayerId']);
            _desarenadorAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['desarenadorAtLayerId']);
            _tuberiaPresionAt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['tuberiaPresionAtLayerId']);
            // Red de Media Tension
            _alimentadorMT = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['alimentadorMtLayerId']);
            _transformadorMT = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['transformadorMtLayerId']);
            _transformadorMixtoMT = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['transformadorMixtoMtLayerId']);
            _tmtLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['tramoMtLayerId']);
            _puestaTierraMT = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['puestaTierraMtLayerId']);
            _pararrayoMT = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['pararrayoMtLayerId']);
            _retenidaMT = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['retenidaMtLayerId']);
            _recloserMT = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['recloserMtLayerId']);
            _estructuraMT = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['estructuraMtLayerId']);
            _reguladorMt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['reguladorMtLayerId']);
            _interruptorMt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['interruptorMtLayerId']);
            _seccionalizadorMt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['seccionalizadorMtLayerId']);
            _seccionadorMt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['seccionadorMtLayerId']);
            // Red de Baja Tension
            _sedLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['sedLayerId']);
            _circuitoLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['circuitoBTLayerId']);
            _tbtLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['tramoBtLayerId']);
            _tapLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['tramoBtAlumbradoLayerId']);
            _acomLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['acometidaLayerId']);
            _sumLayer = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['suministrosLayerId']);
            _equipoControlAp = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['equipoControlApLayerId']);
            _estructuraBt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['estructuraBtLayerId']);
            _retenidaBt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['retenidaBtLayerId']);
            _puestaTierraBt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['puestaTierraBtLayerId']);
            _equipoApBt = _layerRed.allSublayers.find( sublayer => sublayer.id === _configRed['equipoApBtLayerId']);

            _sumFeatureLayer = _mapa.layers.find( layer => layer.id === LY_SUM_ID);

            _redAT = [_tatLayer,_transformadorPotenciaAt ,_centroGeneracionAt ,_equipoProteccionAt ,_estructuraAt ,_barraElectricaAt ,_pararrayoAt ,_puestaTierraAt ,_retenidaAt ,_grupoGeneracionAt ,_casaMaquinaAt ,_bocatomaAt ,_interruptorAt ,_canalesAt ,_camaraAt ,_tunelesAt ,_desarenadorAt ,_tuberiaPresionAt ];
            _redMT = [_setLayer, _alimentadorMT, _transformadorMT, _transformadorMixtoMT, _tmtLayer, _puestaTierraMT, _pararrayoMT, _retenidaMT, _recloserMT, _estructuraMT, _reguladorMt, _interruptorMt, _seccionalizadorMt, _seccionadorMt];
            _redBT = [_sedLayer, _circuitoLayer, _tbtLayer, _tapLayer, _acomLayer, _sumLayer, _equipoControlAp, _estructuraBt, _retenidaBt, _puestaTierraBt, _equipoApBt, _sumFeatureLayer];

            // _generarPopupTemplates();
        });
    }

    //--------------------------------------------------------------------------
    //  Genera los popups que utilizarán los elementos
    //--------------------------------------------------------------------------
    function _generarPopupTemplates(){
        // TODO: Obtener templates desde configuracion
        _sedLayer.popupTemplate = {
            title: "{SED_COD_SED}",
            content: "Subestación: {SED_NOM_SED}."
        };
        _sumFeatureLayer.popupTemplate = {
            title: "{SUM_COD_SUM_COM}"
        };
        _tbtLayer.popupTemplate = {
            title: "{TBT_COD_TBT}",
            content: `Subestación: {TBT_COD_SED} <br>
                      Circuito: {TBT_NOM_SAL}`
        }
    }

    //--------------------------------------------------------------------------
    //  Muestro u Oculta un tipo de red
    //--------------------------------------------------------------------------
    function _alternarVisibilidadRed(arrayRed, mostrar){
        arrayRed.forEach( (capa) => {
            if (capa) {
                capa.visible = mostrar;
            }
        });
    }

    //--------------------------------------------------------------------------
    //  Encuentra una subestación de transformación por su código y muestra solo
    //  la red que dependa de él
    //--------------------------------------------------------------------------
    function _filtrarRedSet(codSet){
        // Ocultar Red de Alta tensión
        _alternarVisibilidadRed(_redAT, _ocultar);

        if (codSet){
            if (!Array.isArray(codSet)){
                codSet = [codSet];
            }

            // Guardar referencia del filtro actual de set
            _filtroActual['set'] = codSet;

            // Definir Definition expresion para Sets
            _setLayer.definitionExpression = codSet.reduce( (consulta, codigo) => `${consulta} OR SET_COD_SET = '${codigo}'`, '1=0' ) ;

            // Ubicar alimentadores dependientes
            let qTask = new QueryTask({
                url: _alimentadorMT.url
            });
            qTask.execute({
                returnGeometry: false,
                outFields: ["ALI_COD_ALI"],
                where: codSet.reduce( (consulta, codigo) => `${consulta} OR ALI_COD_SET = '${codigo}'`, '1=0' )
            }).then((featureSet) => {
                if (featureSet.features.length > 0){
                    let arrayCodigosALI = featureSet.features.map( feature => feature.attributes["ALI_COD_ALI"]);
                    _filtrarRedAlimentador(arrayCodigosALI);
                }else{
                    _mostrarMensajeErrorFiltro(_mensajeErrorSet, "* No se encontró red para la SET indicada.");
                }
            });
        }else{
            // Limpiar el definitionExpression y los alimentadores
            _setLayer.definitionExpression = '';
            // Guardar referencia del filtro actual de set
            _filtroActual['set'] = [];
            _filtrarRedAlimentador();
            _alternarVisibilidadRed(_redAT, _mostrar);
        }

    }

    //--------------------------------------------------------------------------
    //  Encuentra un alimentador por su código y muestra solo la red que
    //  dependa de él
    //--------------------------------------------------------------------------
    function _filtrarRedAlimentador(codigosAlimentador){
        _alternarVisibilidadRed(_redMT, _mostrar);
        // Filtrar elementos de Red
        if (codigosAlimentador){
            if (!Array.isArray(codigosAlimentador)){
                codigosAlimentador = [codigosAlimentador];
            }

            // Guardar referencia del filtro actual de ali
            _filtroActual['ali'] = codigosAlimentador;

            // Aplicar definitio expresion a capas que dependen del alimentador
            _alimentadorMT.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR ALI_COD_ALI = '${codigo}'`, '1=0');
            _transformadorMT.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR TRAF_COD_ALI = '${codigo}'`, '1=0');
            _transformadorMixtoMT.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR TRAF_COD_ALI = '${codigo}'`, '1=0');
            _tmtLayer.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR TMT_COD_ALI = '${codigo}'`, '1=0');
            _puestaTierraMT.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR PAT_COD_ALI = '${codigo}'`, '1=0');
            _pararrayoMT.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR PAR_COD_ALI = '${codigo}'`, '1=0');
            _retenidaMT.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR RET_COD_ALI = '${codigo}'`, '1=0');
            _recloserMT.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR REC_COD_ALI = '${codigo}'`, '1=0');
            _estructuraMT.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR NOD_COD_ALI = '${codigo}'`, '1=0');
            _reguladorMt.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR REG_COD_ALI = '${codigo}'`, '1=0');
            _interruptorMt.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR EQP_INT_COD_ALI = '${codigo}'`, '1=0');
            _seccionalizadorMt.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR EQP_SEC_COD_ALI = '${codigo}'`, '1=0');
            _seccionadorMt.definitionExpression = codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR SEC_COD_ALI = '${codigo}'`, '1=0');

            _acercarALayer(_tmtLayer).then( () => {
                let qTask = new QueryTask({
                    url: _sedLayer.url
                });
                let parte = 1000;
                let consultas = [];
                qTask.executeForCount({
                    returnGeometry: false,
                    where: codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR SED_COD_ALI = '${codigo}'`, '1=0' )
                }).then( cantidad => {
                    for (let i = 0; i < cantidad; i += parte){
                        consultas.push(qTask.execute({
                            returnGeometry: false,
                            outFields: ["SED_COD_SED"],
                            orderByFields:["SED_COD_SED"],
                            where: codigosAlimentador.reduce( (consulta, codigo) => `${consulta} OR SED_COD_ALI = '${codigo}'`, '1=0' ),
                            start: i,
                            num: parte
                        }));
                    }
                    Promise.all(consultas).then((Resultados) => {
                        let features = Resultados.reduce( (grupo, featurSet) => grupo.concat(featurSet.features), []);
                        if (features.length > 0){
                            let arrayCodigosSED = features.map( feature => feature.attributes["SED_COD_SED"]);
                            _filtrarRedSed(arrayCodigosSED);
                            _alternarVisibilidadRed(_redBT, _mostrar);
                        }else{
                            _alternarVisibilidadRed(_redBT, _ocultar);
                        }
                    });
                });

            }).catch ( () => {
                _tmtLayer.definitionExpression = null;
                // Guardar referencia del filtro actual de ali
                _filtroActual['ali'] = [];
                _mostrarMensajeErrorFiltro(_mensajeErrorAlimentador, "* No se encontró red para el alimentador indicado.");
            });
        }else{
            _redMT.forEach( elemento => elemento.definitionExpression = '1=1');
            // Guardar referencia del filtro actual de ali
            _filtroActual['ali'] = [];
            _filtrarRedSed();
            _alternarVisibilidadRed(_redBT, _mostrar)
        }
    }
    //--------------------------------------------------------------------------
    //  Encuentra una Subestación de distribución por su código y muestra
    //  solo la red que dependa de ella
    //--------------------------------------------------------------------------
    function _filtrarRedSed(codigosSED){
        let qTaskSed = new QueryTask({ url: _sedLayer.url });
        let resolveFiltro, noResueltoSuministro;
        let promise = new Promise((resolve, reject) => {
            resolveFiltro = resolve;
            noResueltoSuministro = reject;
        });
        // Encontrar SED
        if (codigosSED){
            if (!Array.isArray(codigosSED)){
                codigosSED = [codigosSED];
            }
            let parte = 250;
            let consultas = [];
            // Hacer consultas parciales de 250 en 250 codigos de SED
            for (let i = 0; i < codigosSED.length; i += parte){
                consultas.push(qTaskSed.execute({
                    returnGeometry: true,
                    outSpatialReference: _view.spatialReference,
                    where: codigosSED.slice(i, i + parte).reduce( (consultaActual, codActual) => {
                        return `${consultaActual} OR SED_COD_SED = '${codActual}' OR SED_ETQ_SED = '${codActual}'`;
                    }, '1=0'),
                    outFields: ['SED_COD_SED']
                }));
            }
            // Encontrar todas las SED en el array
            Promise.all(consultas).then( Resultados => {
                let features = Resultados.reduce( (grupo, featurSet) => grupo.concat(featurSet.features), []);
                if (features.length < 1){
                    _mostrarMensajeErrorFiltro(_mensajeErrorSed, "* No se encontró subestación de distribución.");
                    noResueltoSuministro();
                }else{
                    _sedLayer.definitionExpression =  features.reduce( (consulta, feature) => `${consulta} OR SED_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _circuitoLayer.definitionExpression =  features.reduce( (consulta, feature) => `${consulta} OR SAL_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _tbtLayer.definitionExpression =  features.reduce( (consulta, feature) => `${consulta} OR TBT_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _tapLayer.definitionExpression =  features.reduce( (consulta, feature) => `${consulta} OR TAP_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _acomLayer.definitionExpression =  features.reduce( (consulta, feature) => `${consulta} OR ACO_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _sumLayer.definitionExpression =  features.reduce( (consulta, feature) => `${consulta} OR SUM_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _sumFeatureLayer.definitionExpression =  features.reduce( (consulta, feature) => `${consulta} OR SUM_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _equipoControlAp.definitionExpression = features.reduce( (consulta, feature) => `${consulta} OR EQP_CTRL_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _estructuraBt.definitionExpression = features.reduce( (consulta, feature) => `${consulta} OR NOD_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _retenidaBt.definitionExpression = features.reduce( (consulta, feature) => `${consulta} OR RET_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _puestaTierraBt.definitionExpression = features.reduce( (consulta, feature) => `${consulta} OR PAT_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');
                    _equipoApBt.definitionExpression = features.reduce( (consulta, feature) => `${consulta} OR EQP_AP_COD_SED = '${feature.attributes['SED_COD_SED']}'`, '1=0');

                    // Filtrar elementos de Red
                    _emitChange();
                    resolveFiltro();
                }
            }).catch( error => console.log(error));
        }else{
            _redBT.forEach( elemento => elemento.definitionExpression = '1=1');
            // Guardar referencia del filtro actual de sed
            _filtroActual['sed'] = [];
            _emitChange();
            resolveFiltro();
        }
        return promise;
    }

    function _mostrarRelacionSuministroSED(codSuministro) {
        let qTaskSum = new QueryTask({ url: _sumFeatureLayer.url + '/' + _sumFeatureLayer.layerId });
        let qTaskSed = new QueryTask({ url: _sedLayer.url });

        _limpiarMarcadores();

        qTaskSum.execute({
            returnGeometry: true,
            outSpatialReference: _view.spatialReference,
            outFields: [ "SUM_COD_SED" ],
            where: `SUM_COD_SUM_COM = '${codSuministro}'`
        }).then( (featureSet) => {
            if (featureSet.features.length === 1){
                let suministro = featureSet.features[0];
                let codSed = suministro.attributes["SUM_COD_SED"];
                if (codSed){
                    // Buscar SED
                    qTaskSed.execute({
                        returnGeometry: true,
                        outSpatialReference: _view.spatialReference,
                        where: `SED_COD_SED = '${codSed}'`
                    }).then( (featureSet) => {
                        if (featureSet.features.length === 1){
                            let sed = featureSet.features[0];
                            _colocarMarcador([suministro, sed]);
                            _view.goTo([suministro, sed]);
                        }else{
                            _colocarMarcador([suministro]);
                            _view.goTo({target: suministro, zoom: 19});
                        }
                    });
                }else{
                    _colocarMarcador([suministro]);
                    _view.goTo({target: suministro, zoom: 19});
                }

            }else{
                _mostrarMensajeErrorFiltro(_mensajeErrorSum, "* No se encontró suministro.");

            }
        });

    }

    //--------------------------------------------------------------------------
    //  Busca una zona de faturación ubica toda la red que depende de ella
    //  para mostrarla
    //--------------------------------------------------------------------------
    function _filtrarRedZona(codigoZona){

        if (!codigoZona){
            _redBT.concat(_redMT).forEach( capa =>  capa.definitionExpression = "1=1");
            return;
        }

        // Obtener Zona
        let ubicarZona = _zonaLayer.queryFeatures({
            where: `ZON_FACT_COD_ZON = '${codigoZona}' OR ZON_FACT_NOM_ZON = '${codigoZona}'`,
            returnGeometry: true,
            outSpatialReference: _view.spatialReference
        });

        ubicarZona.then( featureSet => {

            let fZona = featureSet.features[0];
            if (!fZona){
                _mostrarMensajeErrorFiltro(_mensajeErrorZona, "* No se encontró la zona especificada.");
                return;
            }

            // Acercar a la zona
            _view.goTo(fZona.geometry.extent);

            // Obtener cada capa filtrando la geometria de la zona
            _redBT.concat(_redMT).forEach( capa => {
                // Obtener la cantidad de elementos
                let tareas = [];
                let campos = capa === _sumFeatureLayer ? ['SUM_COD_SUM','OBJECTID'] : ['OBJECTID'];
                let qTask = capa.source.queryTask || new QueryTask(capa.url);
                qTask.executeForCount({
                    geometry: fZona.geometry
                }).then( cantidad => {
                    // Hacer una consulta por cada mil elementos
                    for (let i = 0; 1000 * i <= cantidad; i++){
                        tareas.push(
                            capa.queryFeatures({
                                geometry: fZona.geometry,
                                outFields: campos,
                                num: 1000,
                                start: 1000 * i
                            })
                        );
                    }

                    // Cuando hayan terminado todas las consultas a la capa.
                    Promise.all(tareas).then( arrayFeatureSet => {
                        // Concatenar todos los features en un solo array
                        let features = arrayFeatureSet.reduce( (arrayTotal, featureSet) => arrayTotal.concat(featureSet.features), []);
                        let concatenado;
                        if ( capa === _sumFeatureLayer){
                            concatenado = features.reduce( (anterior, feature) => `${anterior},'${feature.attributes[campos[0]]}'`, "'00'" );
                            capa.arrayCodigosSum = features.map( f => f.attributes[campos[0]]);
                        }else{
                            concatenado = features.reduce( (anterior, feature) => `${anterior},${feature.attributes[campos[0]]}`, '-1' );
                        }
                        // Actualizar el definition expresion con el campo debido
                        capa.definitionExpression = `${campos[0]} IN (${concatenado})`;
                    });
                });



            });

        });

    }

    //--------------------------------------------------------------------------
    //  Hace un acercamiento a la extensión visible actual de una capa
    //--------------------------------------------------------------------------
    function _acercarALayer(layer){
        let qTask = new QueryTask({
            url: layer.url
        });

        return new Promise( (resolve, reject ) => {
            qTask.executeForExtent({
                returnGeometry: true,
                outSpatialReference: _view.spatialReference,
                where: layer.definitionExpression || '1=1'
            }).then((result) => {
                if (result.count > 0){
                    resolve(true);
                    _view.goTo(result.extent);
                }else{
                    reject(false);
                }
            });
        });
    }
    //--------------------------------------------------------------------------
    //  Coloca un marcador en la o las geometrías que se indiquen
    //--------------------------------------------------------------------------
    function _colocarMarcador(graphics, symbols){
        let defaultSymbol = null;
        if (!symbols || graphics.length !== symbols.length){
            defaultSymbol = new PictureMarkerSymbol({
                url: "js/widgets/FiltroAvanzado/img/pin.png",
                width: 15,
                height: 19.5,
                yoffset: 10
            });
        }

        graphics.forEach( (graphic) => {
            _view.graphics.add( new Graphic({
                geometry: graphic.geometry,
                symbol: defaultSymbol,
                attributes: []
            }));
        });
    }
    function _limpiarMarcadores(){
        _view.graphics.removeAll();
    }

    function _mostrarMensajeErrorFiltro(_nodoMensaje, mensaje){
        _nodoMensaje.textContent = mensaje;
        _nodoMensaje.classList.add('activo');
        setTimeout(() => _nodoMensaje.classList.remove('activo'), 3000)
    }

    return Declare([Evented], {

        //----------------------------------
        //  firstName
        //----------------------------------
        constructor: function(container, opciones){
            _container = container;
            _instancia = this;

            // Obtener referencia a mapa
            _view = opciones.view;
            _mapa = opciones.view.map;
            _layerRed = opciones.red;
            _configRed = opciones.configRed;

            _inicializar();
        },
        ocultarSuministros: () => {_sumFeatureLayer.visible = false},
        mostrarSuministros: () => {_sumFeatureLayer.visible = true},
        getFiltroActual: () => _filtroActual

    });
});