/**
 * Created by emenendez on 24/03/2017.
 */
'use strict';
define([
    // Dojo
    "dojo/_base/declare",

    // Esri
    "esri/Graphic",
    "esri/layers/GraphicsLayer",
    "esri/geometry/Point",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/symbols/PictureMarkerSymbol",

    // Templates
    "dojo/text!./templates/streetviewTemplate.html",

    // Config
    // "dojo/text!./config/..."

], function(
    // Dojo
    Declare,

    // Esri
    Graphic,
    GraphicsLayer,
    Point,
    SimpleMarkerSymbol,
    PictureMarkerSymbol,

    // Templates
    StreetViewTemplate
){

    //--------------------------------------------------------------------------
    //
    //  Referencias al DOM
    //
    //--------------------------------------------------------------------------
    let _container;
    let _stretviewBody;

    //--------------------------------------------------------------------------
    //
    //  Referencias a Objetos
    //
    //--------------------------------------------------------------------------
    let _instancia;
    let _view;
    let _map;
    let _streetviewLayer;
    let _ptoPov;
    let _panorama;
    let _widgetActivo = false;
    //--------------------------------------------------------------------------
    //
    //  Constantes
    //
    //--------------------------------------------------------------------------
    // const _config... = JSON.parse(Config...);

    //--------------------------------------------------------------------------
    //  Activa el funcionamiento del widget cuando este es mostrado por primera
    //  vez
    //--------------------------------------------------------------------------
    function _activar(activar){
        if (!activar){
            _widgetActivo = false;
            if (_streetviewLayer){
                _streetviewLayer.visible = false;
            }
        }else{
            if (!_panorama){
                _prepararStreetView();
            }
            _widgetActivo = true;
            if (_streetviewLayer){
                _streetviewLayer.visible = true;
            }
        }
    }

    function _inicializar() {
        // Cargar Estilos
        if  (!document.head.querySelector('streetViewWidget')){
            let cssLink = document.createElement('link');
            cssLink.id = "streetViewWidget";
            cssLink.rel = 'stylesheet';
            cssLink.href = './js/widgets/StreetView/css/streetview.css';
            document.head.appendChild(cssLink);
        }

        _container.innerHTML = StreetViewTemplate;

        _capturarReferenciasDOM();


    }

    //--------------------------------------------------------------------------
    //  Capturar referencias al DOM
    //--------------------------------------------------------------------------
    function _capturarReferenciasDOM(){
        _stretviewBody = _container.querySelector('#streetview-body');
    }

    function _prepararStreetView(){
        // Crear punto para represetar punto de vista en el mapa
        _ptoPov = new Graphic({
            geometry: _view.center,
            symbol: new PictureMarkerSymbol({
                url: "img/compass.png",
                with: 6,
                height: 10
            })
        });

        // Crear y Agregar capa de StreetView
        _streetviewLayer = new GraphicsLayer({
            id: "stretview"
        });
        _map.layers.add(_streetviewLayer);

        // Crear objeto de StreetViewPanorama
        _panorama = new google.maps.StreetViewPanorama(
            _stretviewBody,
            {
                position: {lat: -15.838847653705768, lng: -70.02233505246605},
                pov: {heading: 165, pitch: 0},
                zoom: 1
            }
        );

        _vincularEventos();
    }
    //--------------------------------------------------------------------------
    //  Vincular eventos
    //--------------------------------------------------------------------------
    function _vincularEventos(){

        // Escuchar el evento click del mapa
        _view.on('click', (e) => {
            if (_widgetActivo){
                _panorama.setPosition({lat: e.mapPoint.latitude, lng: e.mapPoint.longitude});
            }

        });

        // Escuchar cambio en punto de vista de panorama
        _panorama.addListener('pov_changed', () => {
            if (_streetviewLayer.loaded){
                let temp = _ptoPov.clone();

                temp.geometry.latitude  = _panorama.getLocation().latLng.lat();
                temp.geometry.longitude= _panorama.getLocation().latLng.lng();
                temp.symbol.angle = _panorama.pov.heading;

                _streetviewLayer.graphics.add(temp);
                _streetviewLayer.graphics.remove(_ptoPov);
                _ptoPov = temp;
            }
        });

    }

    return Declare(null, {

        //----------------------------------
        //  Constructor
        //----------------------------------
        constructor: function(container, opciones){
            _container = container;
            _view = opciones.view;
            _map = opciones.map;
            _widgetActivo = opciones.activar || false;
            _inicializar();
        },
        activar: (activar) => { _activar(activar); }
    });

});