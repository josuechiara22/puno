/**
 * Created by emenendez on 14/02/2017.
 */
var dojoConfig = {
    locale: "es",
    packages: [
        {
            name: "app",
            location: location.pathname.replace(/\/[^/]+$/, "") + "./js"
        },
        {
            name: "vendor",
            location: location.pathname.replace(/\/[^/]+$/, "") + "./vendor"
        }
    ]
};