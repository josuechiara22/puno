/**
 * Created by emenendez on 14/02/2017.
 */
const LY_SUM_ID = 'flSuministros';
const LY_RED_ID = 'red-elpu';
let app = {};
require([
    // Esri
    "esri/Map",
    "esri/views/MapView",
    // Request
    "esri/request",
		
    // Symbols
    "esri/symbols/TextSymbol",

    // Layers
    "esri/layers/GraphicsLayer",
    "esri/layers/MapImageLayer",
    "esri/layers/FeatureLayer",

    // Widgets
    "esri/widgets/Search",
    "esri/widgets/BasemapGallery",
    "esri/widgets/Legend",
    "esri/widgets/LayerList",
    "esri/widgets/Print",

    // App
    "dojo/text!./js/appConfig.json",
    "app/widgets/FiltroAvanzado/FiltroAvanzado",
    "app/widgets/MapasTematicos/MapasTematicos",
	"app/widgets/ZoomXY/ZoomXY",
    "app/widgets/StreetView/StreetView",

    // Vue
    "app/widgets/WidgetContainer/WidgetContainer",

    // Dojo
    "dojo/domReady!"
],function(
    // Esri
    Map,
    MapView,
	//Request
	esriRequest,
    // Symbols
    TextSymbol,

    // Layers
    GraphicsLayer,
    MapImageLayer,
    FeatureLayer,

    // Widgets
    Search,
    BasemapGallery,
    Legend,
    LayerList,
    Print,

    // App
    Config,
    FiltroAvanzado,
    MapasTematicos,
	ZoomXY,
    StreetView
    // Dojo
){
    const appConfig = JSON.parse(Config);
    const suministrosLayerId = appConfig["servicio-red-elpu"].suministrosLayerId;
    const acometidaLayerId = appConfig["servicio-red-elpu"].acometidaLayerId;
    const tramoBtLayerId = appConfig["servicio-red-elpu"].tramoBtLayerId;
    const tramoBtAlumbradoLayerId = appConfig["servicio-red-elpu"].tramoBtAlumbradoLayerId;
    const circuitoBTLayerId = appConfig["servicio-red-elpu"].circuitoBTLayerId;
    const tramoMtLayerId = appConfig["servicio-red-elpu"].tramoMtLayerId;
    const sedLayerId = appConfig["servicio-red-elpu"].sedLayerId;

    app.config = appConfig;

    app.map = new Map({
        basemap: 'osm'
    });

    app.view = new MapView({
        container: 'mapView',
        map: app.map,
        extent: {"xmin":-7932371.943621117,"ymin":-1903660.3149883521,"xmax":-7611947.921049674,"ymax":-1458491.0622555076,"spatialReference":{"latestWkid":3857,"wkid":102100}}
		
    });

    app.view.watch('updating', (isUpdating) => {
        if (isUpdating){
            document.getElementById('indicador-carga').classList.add('activo');
        }else{
            document.getElementById('indicador-carga').classList.remove('activo');
        }
    });

    app.view.on('pointer-move', evt => {
        let punto = app.view.toMap({x: evt.x, y: evt.y});
        let coordendasContainer = document.querySelector('#barra-coordenadas .coordenadas');
        let coordenadasUTM = app.latLngToUTM(punto.latitude, punto.longitude);
        coordendasContainer.textContent = `GCS : ${punto.latitude.toFixed(6)}, ${punto.longitude.toFixed(6)} | UTM WGS84: ${coordenadasUTM.x.toFixed(6)}E, ${coordenadasUTM.y.toFixed(6)}N ZONA: ${coordenadasUTM.zona}`;
        //Datos de Actualización
        let actualizadoContainer = document.querySelector('#barra-actualizado .coordenadas');
        let actualizado = app.config["fecha-actualizacion"]
        actualizadoContainer.textContent = actualizado
        
    });

	
    // Capas
    let lRed = new MapImageLayer({
        url: `${app.config["url-server-gis"]}/${app.config["servicio-red-elpu"]["nombre"]}/MapServer`,
        id: LY_RED_ID,
        title: 'Red ElectroPuno',
        // sublayers: [
        //     {id: acometidaLayerId, visible: true},
        //     {id: tramoBtLayerId, visible: true},
        //     {id: tramoBtAlumbradoLayerId, visible: true},
        //     {id: circuitoBTLayerId, visible: true},
        //     {id: tramoMtLayerId, visible: true},
        //     {id: sedLayerId, visible: true}
        // ]
    });
	
	
    app.view.then(function() {
		app.map.layers.items.forEach(function(item, index) {
			//--Nos Asguremoas que el Layer este Cargado
			item.then(function() {
				item.allSublayers.forEach(function(itemLayer, index){
					var _layer={};
						_layer.title = itemLayer.title;
						_layer.layer = itemLayer;

					
					esriRequest(itemLayer.url + '?f=json',{
						responseType: "json"
					}).then(function(r){						
					    //layer.layerInfos[layerId].info = r; //add result to layer's LayerInfo  
						var popupContent = {  
								title: '', 							
								content:[{ type: "fields",fieldInfos: []},{type: "attachments"}]
							};
							if (r.data.name=='Subestación de Distribución'){popupContent.content.push({type: "text"  ,text:'<STRONG>Lista de Adjuntos</STRONG>{OBJECTID:getAttachmentsSED}'})};
							if (r.data.name=='Estructura de Media Tensión'){popupContent.content.push({type: "text"  ,text:'<STRONG>Lista de Adjuntos</STRONG>{OBJECTID:getAttachmentsEMT}'})};
							if (r.data.name=='Estructura de Baja Tensión'){popupContent.content.push({type: "text"  ,text:'<STRONG>Lista de Adjuntos</STRONG>{OBJECTID:getAttachmentsEBT}'})};
							if (r.data.name=='Nodo de Alta Tensión'){popupContent.content.push({type: "text"  ,text:'<STRONG>Lista de Adjuntos</STRONG>{OBJECTID:getAttachmentsEAT}'})};
							
							//array.forEach(r.data.fields, function (field) {  
							r.data.fields.forEach(function (field){
								if (field.type !== 'esriFieldTypeOID'  && field.type !== 'esriFieldTypeGeometry' && 
								    field.type !== 'esriFieldTypeBlob' && field.type !== 'esriFieldTypeRaster'   &&
									field.type !== 'esriFieldTypeGUID' && field.type !== 'esriFieldTypeGlobalID' && 
									field.type !== 'esriFieldTypeXML') {  
									/*Definimos el Titulo del Popup*/
									if (popupContent.content[0].fieldInfos.length==0){popupContent.title='{' + field.name + '}'}
								    //var _fieldName = field.name;
									if (field.type == 'esriFieldTypeDate'){
										popupContent.content[0].fieldInfos.push({fieldName: field.name, 
																				 visible: true,  
																				 label: field.alias + ': ',
																				 format: {dateFormat:'day-short-month-year'}                                                                          
																			});

									}else{
										popupContent.content[0].fieldInfos.push({fieldName: field.name, 
																				 visible: true,  
																				 label: field.alias + ': '  
																			});
									}  
								}  
							});

							itemLayer.popupTemplate = popupContent;
							//return popupContent;  
						}); 						
					})
				});
			});
            app.view.popup.dockOptions.position = "top-right";
	});
	getAttachmentsSED  = function (value, key, data) {return getAttachments(value, key, data,96)}
	getAttachmentsEMT  = function (value, key, data) {return getAttachments(value, key, data,91)}
	getAttachmentsEBT  = function (value, key, data) {return getAttachments(value, key, data,27)}
	getAttachmentsEAT  = function (value, key, data) {return getAttachments(value, key, data,123)}
	
	getAttachments = function (value, key, data, id) {
		//--Crea Contenedor para los Adjuntos
		var contenedor = '<div id ="popup-rel-' + value + '"></div>'
		var Url = 'https://arcgis.electropuno.com.pe/arcgis/rest/services/RedElectroPuno/MapServer/' + id + '/' + value + '/attachments';
		fetchAttachmToJSON(Url, 'popup-rel-' + value)
		return contenedor;
	}	

    lRed.then( layerRed => {
        // let sumLayer = layerRed.allSublayers.find( subLayer => subLayer.id === suministrosLayerId);
        let lySum = layerRed.findSublayerById(suministrosLayerId);
        lySum.labelsVisible = true;
        lySum.labelingInfo = [{
            labelExpression: "[SUM_COD_RUT]",
            labelPlacement: "always-horizontal",
            symbol: new TextSymbol({
                color: [ 50,50,50,0.85 ],
                font: {
                    size: 10
                }
            }),
            minScale: 564.248588
        }]
        // layerRed.allSublayers.remove()
    });
	
    let lSuministro = new FeatureLayer({
        id: LY_SUM_ID,
        title: 'Suministros',
        url: `${app.config["url-server-gis"]}/${app.config["servicio-red-elpu"]["nombre"]}/MapServer/${suministrosLayerId}`,
        outFields: ["SUM_COD_SUM",'SUM_COD_SUM_COM','SUM_DIR_SUM','SUM_COD_RUT', 'SUM_NOM_SUM'],
        popupTemplate : {
            title: "Suministro",
            expressionInfos: [{
                name: "libro",
                title: "test",
                expression: "($feature.SUM_COD_RUT)"
            }],
            content:  element => {
                let graphic = element.graphic;
                let coordenadas = app.latLngToUTM(graphic.geometry.latitude, graphic.geometry.longitude);
                return`<ul>
                <li>Código: ${graphic.attributes['SUM_COD_SUM']}</li>
                <li>Código de Ruta: ${graphic.attributes['SUM_COD_RUT']}</li>
                <li>Libro:  ${graphic.attributes['SUM_COD_RUT'].slice(0,7)}</li>
                <li>Nombre: ${graphic.attributes['SUM_NOM_SUM']}</li>
                <li>GCS: ${graphic.geometry.latitude.toFixed(6)}, ${graphic.geometry.longitude.toFixed(6)}</li>
                <li>UTM: ${coordenadas.x.toFixed(6)}E, ${coordenadas.y.toFixed(6)}N Zona: ${coordenadas.zona} </li>
              </ul>`;
            }
        }
    });

    app.map.layers.addMany([lRed, lSuministro]);

    // Widget de Busqueda
    let searchWidget = new Search({
        view: app.view
    });
    app.view.ui.add(searchWidget, {
        position: "top-left",
        index: 0
    });

    // Widget de Leyenda
    app.legendWidget = new Legend({
        view: app.view,
        container: Widgets.getContainer('leyenda')
    });

    app.printWidget = new Print({
        view: app.view,       
        container: Widgets.getContainer('print-map'),
        printServiceUrl:"https://arcgis.electropuno.com.pe/arcgis/rest/services/ELPU/ExportWebMap/GPServer/Export%20Web%20Map"
    });

    // Widget de Lista de Capas
    let layerListWidget = new LayerList({
        view: app.view,
        container: Widgets.getContainer('layer-list')        
    });

    // Widget de Selector de Mapas Base
    let basemapGallery = new BasemapGallery({
        view: app.view,
        container: Widgets.getContainer('basemap-gallery')
    });

    // Widget de Filtro Avanzado
    app.filtroAvanzado = new FiltroAvanzado(Widgets.getContainer('filtro-avanzado'), {
        view: app.view,
        red: lRed,
        configRed: appConfig["servicio-red-elpu"]
    });

    // Widget de Mapas Tematicos
    app.mapasTematicos = new MapasTematicos(Widgets.getContainer('mapas-tematicos'), {
        view: app.view,
        layerSuministros: lSuministro,
        layerRed: lRed,
        layerSedId: sedLayerId,
        urlServicio: `${app.config["url-server-gis"]}/${app.config["servicio-red-elpu"]["nombre"]}/MapServer`
    });

    // Widget de StreetView
    app.streetViewWidget = new StreetView(Widgets.getContainer('streetview'), {
        view: app.view,
        map: app.map
    });
    Widgets.$on('cambioWidget', (e) => {
        if (Widgets.$refs.streetview._data._grupo === e.grupo){
            if (e.widgetId === 'streetview'){
                app.streetViewWidget.activar(true);
            }else{
                app.streetViewWidget.activar(false);
            }
        }
    });

    // Eventos en los widgets
    app.filtroAvanzado.on('change', _ => setTimeout(app.mapasTematicos.reload, 2000));
    app.mapasTematicos.on('render-update', () => {
        // Forzar el actualización de la leyenda al detectar un cambio en el render de tematicos
        let info = app.legendWidget.activeLayerInfos.items.find( i => i.layer.id === LY_SUM_ID);
        if (info){
            info.buildLegendElementsForRenderer();
        }
    });

    // Funcion para calcular el valor de las coordenadas UTM
    app.latLngToUTM = function(lat, lon){
        // Compute the UTM zone.
        let xy = new Array(2);
        let zone = Math.floor((lon + 180.0) / 6) + 1;

        LatLonToUTMXY(DegToRad(lat), DegToRad(lon), zone, xy);
        return {
            x: xy[0],
            y: xy[1],
            zona: zone
        }
    }
	
	// Widget de Filtro Avanzado
    app.ZoomXY = new ZoomXY(Widgets.getContainer('zoomxy'), {
        view: app.view,
        red: lRed,
        configRed: appConfig["servicio-red-elpu"]
    });
});

function fetchJSON(url, data){
    const parametros = Object.keys(data).map((key) => {
        return encodeURIComponent(key) + '=' + encodeURIComponent(data[key]);
    }).join('&');
    try{
        return fetch(url, {
            method: 'POST',
            body: parametros,
            headers: {
                'Content-Type': ' application/x-www-form-urlencoded'
            }
        }).then( res => {
            if (!res.ok){
                throw Error(res.statusText);
            }
            return res.json();
        } ).catch( error => {
            console.log(error);
        });
    } catch(e){
        console.log(e);
    }
}

function fetchAttachmToJSON(url,containerId){
    try{
        fetch(url + '?f=json')
		.then(res => res.json())
		.then((out) => {
			var contenido = '<ul class="ac-container">';
			var tabla = document.createElement('table');
			var tableBoddy = tabla.appendChild(document.createElement('tbody'));
			out.attachmentInfos.forEach(function(attr){
				var fila = tableBoddy.insertRow(-1);
				var link = document.createElement('a');
					link.href=url + "/" + attr.id
					link.target = "_blank"
					link.innerHTML  = attr.name
				fila.insertCell(-1).appendChild(link);			
			});	
			contenido += tabla.outerHTML;
			document.getElementById(containerId).innerHTML = contenido;
			console.log('Output: ', out);
			}).catch(err => console.error(err));
	} catch(e){
		console.log(e);
	}
}

// Genera un color aleatorio en nomenclatura hexadecimal
function randomColor(seed){
    let hexValues = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e"];
    let newColor = "#";

    seed = seed || Math.random();
    let randomWSeed = function () {
        let x = Math.sin(seed++) * 10000;
        return x - Math.floor(x);
    };

    for ( let i = 0; i < 6; i++ ) {
        let x = Math.round(randomWSeed() * 14 );
        newColor += hexValues[x];
    }
    return newColor;
}

// Devuelve un color en hexadecimal con el brillo aumentado
function increase_brightness(hex, percent){
    // strip the leading # if it's there
    hex = hex.replace(/^\s*#|\s*$/g, '');

    // convert 3 char codes --> 6, e.g. `E0F` --> `EE00FF`
    if(hex.length === 3){
        hex = hex.replace(/(.)/g, '$1$1');
    }

    let r = parseInt(hex.substr(0, 2), 16),
        g = parseInt(hex.substr(2, 2), 16),
        b = parseInt(hex.substr(4, 2), 16);

    return '#' +
        ((0|(1<<8) + r + (256 - r) * percent / 100).toString(16)).substr(1) +
        ((0|(1<<8) + g + (256 - g) * percent / 100).toString(16)).substr(1) +
        ((0|(1<<8) + b + (256 - b) * percent / 100).toString(16)).substr(1);
}